Download the Pigeon IMU folder to a location of your choosing.  
This folder has all the VIs to use Pigeon.

Copy Begin.vi and Periodic Tasks.vi on top of your existing 
LabVIEW project, overwriting the VIs already there.

When you open your project, it will present a pop-up asking 
for the location of the Pigeon VIs.  Direct it to the location 
where you saved Pigeon IMU.